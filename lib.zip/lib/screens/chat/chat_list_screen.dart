import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../routes/app_routes.dart';

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({super.key});

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;

      final authProvider = context.read<AuthProvider>();
      final chatProvider = context.read<ChatProvider>();
      final userId = authProvider.currentUserId;

      if (userId != null && userId.isNotEmpty) {
        chatProvider.startChatsListener(userId);
      }
    });
  }

  @override
  void dispose() {
    try {
      context.read<ChatProvider>().stopChatsListener();
    } catch (_) {}
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final chatProvider = context.watch<ChatProvider>();
    final authProvider = context.watch<AuthProvider>();
    final currentUserId = authProvider.currentUserId ?? '';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chats'),
      ),
      body: chatProvider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : chatProvider.chats.isEmpty
              ? const Center(
                  child: Text('No chats yet'),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: chatProvider.chats.length,
                  itemBuilder: (context, index) {
                    final doc = chatProvider.chats[index];
                    final data = doc.data() as Map<String, dynamic>;

                    final sellerId = (data['sellerId'] ?? '').toString();
                    final driverId = (data['driverId'] ?? '').toString();
                    final otherUserId =
                        currentUserId == sellerId ? driverId : sellerId;

                    final orderDescription =
                        (data['orderDescription'] ?? 'Chat').toString();
                    final lastMessage = (data['lastMessage'] ?? '').toString();

                    return StreamBuilder<DocumentSnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('users')
                          .doc(otherUserId)
                          .snapshots(),
                      builder: (context, snapshot) {
                        final userData = snapshot.data?.data();
                        final userMap = userData is Map<String, dynamic>
                            ? userData
                            : <String, dynamic>{};

                        final otherEmail =
                            (userMap['email'] ?? 'Unknown user').toString();
                        final isOnline = userMap['isOnline'] == true;

                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: ListTile(
                            onTap: () {
                              Navigator.pushNamed(
                                context,
                                AppRoutes.chatScreen,
                                arguments: ChatScreenArgs(
                                  chatId: doc.id,
                                  title: orderDescription,
                                ),
                              );
                            },
                            leading: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                const CircleAvatar(
                                  radius: 24,
                                  child: Icon(Icons.person),
                                ),
                                Positioned(
                                  right: -1,
                                  bottom: -1,
                                  child: Container(
                                    width: 12,
                                    height: 12,
                                    decoration: BoxDecoration(
                                      color: isOnline
                                          ? Colors.green
                                          : Colors.grey,
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: const Color(0xFF101216),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            title: Text(
                              orderDescription,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                Text(
                                  otherEmail,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  lastMessage.isEmpty
                                      ? 'No messages yet'
                                      : lastMessage,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                            trailing: Icon(
                              isOnline
                                  ? Icons.circle
                                  : Icons.access_time_outlined,
                              size: isOnline ? 12 : 18,
                              color: isOnline ? Colors.green : Colors.grey,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
    );
  }
}