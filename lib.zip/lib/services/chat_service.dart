import 'package:cloud_firestore/cloud_firestore.dart';

import '../core/constants/app_status.dart';

class ChatService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> sendChatRequest({
    required String orderId,
    required String sellerId,
    required String driverId,
    required String orderDescription,
    required String pickupLocation,
    required String dropoffLocation,
  }) async {
    final chatId = '${orderId}_${sellerId}_$driverId';

    await _firestore.collection('chat_requests').doc(chatId).set({
      'orderId': orderId,
      'sellerId': sellerId,
      'driverId': driverId,
      'orderDescription': orderDescription,
      'pickupLocation': pickupLocation,
      'dropoffLocation': dropoffLocation,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Stream<QuerySnapshot> getChatRequestsForSeller(String sellerId) {
    return _firestore
        .collection('chat_requests')
        .where('sellerId', isEqualTo: sellerId)
        .where('status', whereIn: ['pending', 'chat_open'])
        .snapshots();
  }

  Future<void> acceptChatRequest({
    required String requestId,
    required Map<String, dynamic> requestData,
  }) async {
    final chatRef = _firestore.collection('chats').doc(requestId);
    final requestRef = _firestore.collection('chat_requests').doc(requestId);

    await _firestore.runTransaction((transaction) async {
      transaction.set(chatRef, {
        'orderId': requestData['orderId'],
        'sellerId': requestData['sellerId'],
        'driverId': requestData['driverId'],
        'orderDescription': requestData['orderDescription'],
        'pickupLocation': requestData['pickupLocation'],
        'dropoffLocation': requestData['dropoffLocation'],
        'participantIds': [
          requestData['sellerId'],
          requestData['driverId'],
        ],
        'lastMessage': '',
        'lastMessageSenderId': '',
        'lastMessageAt': null,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      transaction.update(requestRef, {
        'status': 'chat_open',
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> confirmDriverForDelivery({
    required String requestId,
    required Map<String, dynamic> requestData,
  }) async {
    final requestRef = _firestore.collection('chat_requests').doc(requestId);
    final orderRef = _firestore
        .collection('orders')
        .doc((requestData['orderId'] ?? '').toString());

    await _firestore.runTransaction((transaction) async {
      transaction.update(requestRef, {
        'status': 'approved',
        'updatedAt': FieldValue.serverTimestamp(),
      });

      transaction.update(orderRef, {
        'driverId': requestData['driverId'],
        'status': AppStatus.accepted,
      });
    });
  }

  Future<void> rejectChatRequest(String requestId) async {
    await _firestore.collection('chat_requests').doc(requestId).update({
      'status': 'rejected',
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot> getUserChats(String userId) {
    return _firestore
        .collection('chats')
        .where('participantIds', arrayContains: userId)
        .orderBy('updatedAt', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot> getMessages(String chatId) {
    return _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Future<void> sendMessage({
    required String chatId,
    required String senderId,
    required String text,
  }) async {
    final cleanText = text.trim();
    if (cleanText.isEmpty) return;

    final messageRef = _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .doc();

    final chatRef = _firestore.collection('chats').doc(chatId);

    await _firestore.runTransaction((transaction) async {
      transaction.set(messageRef, {
        'chatId': chatId,
        'senderId': senderId,
        'text': cleanText,
        'isRead': false,
        'createdAt': FieldValue.serverTimestamp(),
      });

      transaction.update(chatRef, {
        'lastMessage': cleanText,
        'lastMessageSenderId': senderId,
        'lastMessageAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> markMessagesAsRead({
    required String chatId,
    required String currentUserId,
  }) async {
    final messages = await _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .where('isRead', isEqualTo: false)
        .get();

    for (final doc in messages.docs) {
      final data = doc.data();
      if ((data['senderId'] ?? '').toString() != currentUserId) {
        await doc.reference.update({'isRead': true});
      }
    }
  }
}